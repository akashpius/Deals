<?php

class Phoenixsharp_Catdeals_Model_Mysql4_Catdeals_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract {

    public function _construct() {
//parent::__construct();
        $this->_init('catdeals/catdeals');
    }

}
