<?php

class Phoenixsharp_Catdeals_Block_Catdeals extends Mage_Core_Block_Template {
    
}
