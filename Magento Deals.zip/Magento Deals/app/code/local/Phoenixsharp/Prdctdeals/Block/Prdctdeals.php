<?php

class Phoenixsharp_Prdctdeals_Block_Prdctdeals extends Mage_Core_Block_Template {
    
}
